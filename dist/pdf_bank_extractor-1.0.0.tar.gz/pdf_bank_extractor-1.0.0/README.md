# PDF Bank Extractor

Extractor de datos bancarios desde archivos PDF.

## Instalación

```bash
pip install pdf_extractor